# Pacote sistema bancário com POO em Python

Description. 
Esse código foi feito para um desafio do curso de Python da DIO.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install pacote_sistema_bancario
```

## Author
Miguel Ângelo

## License
[MIT](https://choosealicense.com/licenses/mit/)